import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http: HttpClient) { }
  baseurl: string = "https://xebiascart.herokuapp.com";
  login(username: string) {
    return this.http.get<any>(`${this.baseurl}/users?username=${username}`)
      .pipe(map(user => {
        if (user) {
          localStorage.setItem('User', JSON.stringify(user));
        }

        return user;
      }));
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('User');
  }
}
