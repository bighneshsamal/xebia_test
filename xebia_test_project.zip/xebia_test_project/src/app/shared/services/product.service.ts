import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }
  baseurl: string = "https://xebiascart.herokuapp.com";
  
  getProductList() {
    return this.http.get<any>(`${this.baseurl}/products`)    
  }

 getFilterList() {
    return this.http.get<any>(`${this.baseurl}/filters`)    
  }
}
